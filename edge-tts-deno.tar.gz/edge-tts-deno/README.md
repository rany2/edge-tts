# Edge TTS Deno

Edge TTS Deno 是 Microsoft Edge 在线文本转语音(TTS)服务的Deno实现版本，支持边缘函数部署。这是一个从Python版 [edge-tts](https://github.com/rany2/edge-tts) 移植的项目。

## 特性

- 使用 Deno 原生 WebSocket
- 支持实时音频流
- 支持多语言和多种语音
- 支持边缘函数部署
- 兼容 OpenAI API 格式
- 完整的类型支持

## 安装

由于这是一个Deno项目，你不需要安装任何包。只需要在你的代码中直接导入即可：

```typescript
import { WebSocketClient } from "https://raw.githubusercontent.com/your-username/edge-tts-deno/main/mod.ts";
```

## 基础用法

### 简单示例

```typescript
import { WebSocketClient } from "./mod.ts";

const client = new WebSocketClient(
  "你好，世界！",
  "zh-CN-XiaoxiaoNeural" // 使用中文语音
);

// 将音频保存到文件
const audioChunks: Uint8Array[] = [];
for await (const chunk of client.stream()) {
  if (chunk.type === "audio") {
    audioChunks.push(chunk.data);
  }
}

const finalAudio = new Uint8Array(
  audioChunks.reduce((acc, chunk) => acc + chunk.length, 0)
);
let offset = 0;
for (const chunk of audioChunks) {
  finalAudio.set(chunk, offset);
  offset += chunk.length;
}

await Deno.writeFile("output.mp3", finalAudio);
```

### 自定义配置

```typescript
const client = new WebSocketClient(
  "Hello, world!",
  "en-US-AriaNeural",
  "+10%",   // 语速
  "+0%",    // 音量
  "+0Hz",   // 音调
  {
    connectTimeout: 5000,    // 连接超时时间
    receiveTimeout: 30000,   // 接收超时时间
  }
);
```

## API 参考

### WebSocketClient

主要的客户端类，用于与Edge TTS服务通信。

```typescript
class WebSocketClient {
  constructor(
    text: string,
    voice?: string,
    rate?: string,
    volume?: string,
    pitch?: string,
    config?: WebSocketClientConfig
  );

  stream(): AsyncGenerator<TTSChunk, void, unknown>;
}
```

### 类型定义

```typescript
interface TTSChunk {
  type: "audio" | "WordBoundary";
  data?: Uint8Array;
  offset?: number;
  duration?: number;
  text?: string;
}

interface WebSocketClientConfig {
  connectTimeout?: number;
  receiveTimeout?: number;
  proxy?: string;
}
```

## 错误处理

该库提供了多种错误类型以帮助你处理可能出现的问题：

```typescript
try {
  for await (const chunk of client.stream()) {
    // 处理音频数据
  }
} catch (error) {
  if (error instanceof WebSocketError) {
    console.error("WebSocket连接错误:", error.message);
  } else if (error instanceof NoAudioReceived) {
    console.error("未收到音频数据");
  } else {
    console.error("其他错误:", error);
  }
}
```

## 边缘函数部署

要在边缘函数环境中使用，你需要确保：

1. 环境支持WebSocket
2. 设置适当的超时时间
3. 处理连接限制

示例配置（Cloudflare Workers）：

```typescript
export interface Env {
  // 你的环境变量
}

export default {
  async fetch(request: Request, env: Env) {
    const client = new WebSocketClient(
      "你好",
      "zh-CN-XiaoxiaoNeural",
      "+0%",
      "+0%",
      "+0Hz",
      {
        connectTimeout: 5000,
        receiveTimeout: 30000,
      }
    );

    const chunks = [];
    for await (const chunk of client.stream()) {
      if (chunk.type === "audio") {
        chunks.push(chunk.data);
      }
    }

    return new Response(
      new Blob(chunks, { type: "audio/mpeg" }),
      {
        headers: {
          "Content-Type": "audio/mpeg",
        },
      }
    );
  },
};
```

## 许可证

MIT

## 贡献

欢迎提交 Issue 和 Pull Request。在提交 PR 之前，请确保：

1. 代码通过 `deno fmt` 格式化
2. 通过 `deno lint` 检查
3. 添加适当的测试
4. 更新相关文档