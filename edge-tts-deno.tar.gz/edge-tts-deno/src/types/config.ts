/**
 * TTS配置接口
 * 参考原edge_tts/data_classes.py中的TTSConfig
 */
export interface TTSConfig {
  /** 语音名称 */
  voice: string;
  
  /** 语速调整 (默认: "+0%") */
  rate: string;
  
  /** 音量调整 (默认: "+0%") */
  volume: string;
  
  /** 音调调整 (默认: "+0Hz") */
  pitch: string;
}

/**
 * WebSocket事件类型
 */
export interface WebSocketEvent {
  data: string | ArrayBuffer;
}

/**
 * WebSocket错误事件类型
 */
export interface WebSocketErrorEvent {
  error: Error;
  message: string;
  type: string;
}

/**
 * 单词边界元数据
 */
export interface WordBoundary {
  type: "WordBoundary";
  offset: number;
  duration: number;
  text: string;
  data?: never; // 确保与TTSChunk类型兼容
}

/**
 * 音频数据块
 */
export interface AudioChunk {
  type: "audio";
  data: Uint8Array;
}

/**
 * 音频或元数据块
 */
export type TTSChunk = AudioChunk | WordBoundary;

/**
 * WebSocket通信状态
 */
export interface CommunicateState {
  /** 部分文本内容 */
  partialText: Uint8Array;
  
  /** 偏移量补偿 */
  offsetCompensation: number;
  
  /** 最后的持续时间偏移 */
  lastDurationOffset: number;
  
  /** 流是否已被调用 */
  streamWasCalled: boolean;
}